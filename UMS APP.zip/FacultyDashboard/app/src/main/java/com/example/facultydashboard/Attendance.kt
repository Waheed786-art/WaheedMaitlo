package com.example.facultydashboard

import android.annotation.SuppressLint
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.ListView
import android.widget.Toast

class Attendance : AppCompatActivity() {
    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_attendance)
        val names = arrayOf("Noor" , "Fatima" , "Saqib" , "Basit" , "Hamza" , "Ahmed")
        val list = findViewById<ListView>(R.id.listView)
        val arrayAdapter = ArrayAdapter(this , android.R.layout.simple_list_item_1 , names)
        list.adapter = arrayAdapter
        list.setOnItemClickListener { parent, view, position, id ->
            Toast.makeText(this, "${names[position]} is selected.}" , Toast.LENGTH_SHORT).show()

        }
    }
}