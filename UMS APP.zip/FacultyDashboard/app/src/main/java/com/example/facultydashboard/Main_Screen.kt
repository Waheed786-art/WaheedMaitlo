package com.example.facultydashboard

import android.annotation.SuppressLint
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ImageView

class Main_Screen : AppCompatActivity() {
    @SuppressLint("WrongViewCast", "MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main_screen)
        val faculty = findViewById<ImageView>(R.id.faculty)

        faculty.setOnClickListener{
            startActivity(Intent(this@Main_Screen , Faculty_Dashboard::class.java))
        }


    }
}